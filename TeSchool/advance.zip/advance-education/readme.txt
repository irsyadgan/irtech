=== Advance Education WordPress Theme ===
Contributors: Themeshopy
Tags:left-sidebar, right-sidebar, one-column, two-columns, grid-layout, custom-colors, custom-background, custom-logo, custom-menu, custom-header, editor-style, featured-images, footer-widgets, full-width-template, theme-options, translation-ready, rtl-language-support, threaded-comments, blog, e-commerce, education
Requires at least: 4.3
Tested up to: 5.0.2
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Advance Education is a fresh, engaging, visually appealing and elegant education WordPress theme for all classes from preschools and kindergartens to schools, colleges and universities. It suits all LMSs, training academies, online education portals, distance learning, coaching centres, mentors, online library, educational websites and everything related to education, learning and teaching.

== Description ==

Advance Education is a fresh, engaging, visually appealing and elegant education WordPress theme for all classes from preschools and kindergartens to schools, colleges and universities. It suits all LMSs, training academies, online education portals, distance learning, coaching centres, mentors, online library, educational websites and everything related to education, learning and teaching. It offers various layout options to change the look and feel of the website from modern to bold and vice versa. This education WordPress theme is adaptable to changing screen size of mobiles, tabs and desktops. It is compatible with all the leading browsers and can be translated into 70+ different languages. It is readily customizable to change its various elements to make it represent your brand. To keep visitors engaged, there are several sections like gallery, testimonial, faculty, contact form etc. Advance Education is made to score good rank in search engine results and its social media icons give the needed exposure to reach maximum people in minimum time. It is based on the latest WordPress version and hence yields a bug-free website. Its interface is simple to understand so any person with no previous coding skills can also use it to design a high performing and professional looking website.  

== Changelog ==

= 0.1 =
* Initial version Released.

== Resources ==

Advance Education WordPress Theme, Copyright 2019 Themeshopy
Advance Education is distributed under the terms of the GNU GPL

Advance Education WordPress Theme is derived from Twenty Sixteen WordPress Theme, Copyright 2014-2015 WordPress.org
Twenty Sixteen is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see .

Theme is Built using the following resource bundles.

1	CSS bootstrap.css
    -- Copyright 2011-2018 The Bootstrap Authors
    -- https://github.com/twbs/bootstrap/blob/master/LICENSE
    
2	JS bootstrap.js
    -- Copyright 2011-2018 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
    -- https://github.com/twbs/bootstrap/blob/master/LICENSE

3	Free to use and abuse under the MIT license.
	-- http://www.opensource.org/licenses/mit-license.php
	-- font-awesome.css and fonts folder
	Font Awesome 5.0.0 by @davegandy - http://fontawesome.io - @fontawesome
 	-- License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)

4	Customizer Pro
	Source: https://github.com/justintadlock/trt-customizer-pro

5   Images used from pixabay.

	Pixabay Images
	License: CC0 1.0 Universal (CC0 1.0)
	Source:	https://pixabay.com/en/service/terms/

	Slider image, copyright maura24
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pixabay.com/en/graduation-graduation-day-2038866/
	
	Post image, copyright rawpixel
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pixabay.com/en/business-deal-laptop-working-2884023/

	Post image, copyright  rawpixel
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pixabay.com/en/desktop-laptop-crafts-still-life-1985856/
	
	Post image, copyright SplitShire
	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pixabay.com/en/photographer-tourist-snapshot-407068/

6   SmoothScroll
	Sources: http://www.smoothscroll.net/
	License: Licensed under the terms of the MIT license.